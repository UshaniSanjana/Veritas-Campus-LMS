import React from "react";

const Programmes = () => {
  return <div>Programmes</div>;
};

export default Programmes;
