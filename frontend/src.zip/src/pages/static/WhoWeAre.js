import React from "react";

const WhoWeAre = () => {
  return <div>WhoWeAre</div>;
};

export default WhoWeAre;
